package URI::URL::tn3270;
require URI::URL::_login;
@ISA = qw(URI::URL::_login);

# sub default_port { 0 }

1;
